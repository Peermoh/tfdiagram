variable "cidr" {
  default = "10.0.0.0/8"
}
resource "aws_vpc" "this" {
  cidr_block = var.cidr
}
resource "aws_subnet" "a" {
  vpc_id = aws_vpc.this.id
}
