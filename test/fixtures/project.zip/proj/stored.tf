# stored, not compressed
resource "aws_sqs_queue" "q" {}
