module "net" {
  source = "./modules/net"
  cidr   = "10.5.0.0/16"
}
resource "aws_s3_bucket" "b" {
  bucket = "demo"
}
