resource "aws_vpc" "ignored" {}
