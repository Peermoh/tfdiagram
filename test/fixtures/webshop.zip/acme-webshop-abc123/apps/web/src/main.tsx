import React from 'react';
import { price } from '@shop/shared';
import App from './App';
