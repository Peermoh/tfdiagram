export const api = (p) => fetch('/api' + p);
