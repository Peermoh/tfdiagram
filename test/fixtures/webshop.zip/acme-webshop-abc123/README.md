# Shop

[![build](x)](y)

An online shop with a React storefront and an Express API backed by Postgres and Redis.

## Getting started

```bash
npm install
npm run dev
```
