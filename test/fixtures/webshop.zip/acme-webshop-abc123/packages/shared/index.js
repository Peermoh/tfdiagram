exports.price = (x) => x;
