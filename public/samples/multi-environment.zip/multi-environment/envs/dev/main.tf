module "web" {
  source    = "../../modules/web"
  name      = "dev"
  cidr      = "10.10.0.0/16"
  instances = 1
}
