module "web" {
  source    = "../../modules/web"
  name      = "prod"
  cidr      = "10.20.0.0/16"
  instances = 3
}
