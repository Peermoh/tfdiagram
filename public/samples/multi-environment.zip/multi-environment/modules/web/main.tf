variable "name" { default = "app" }
variable "instances" { default = 1 }
variable "cidr" { default = "10.50.0.0/16" }

resource "aws_vpc" "this" {
  cidr_block = var.cidr
  tags = { Name = var.name }
}

resource "aws_subnet" "app" {
  vpc_id     = aws_vpc.this.id
  cidr_block = cidrsubnet(var.cidr, 8, 1)
}

resource "aws_security_group" "app" {
  name   = "${var.name}-sg"
  vpc_id = aws_vpc.this.id
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "app" {
  count                  = var.instances
  ami                    = "ami-0abcdef1234567890"
  instance_type          = "t3.micro"
  subnet_id              = aws_subnet.app.id
  vpc_security_group_ids = [aws_security_group.app.id]
}

resource "aws_s3_bucket" "logs" {
  bucket = "${var.name}-logs-example"
}
