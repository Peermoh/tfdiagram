# Multi environment sample
Two environments (dev, prod) calling one shared module. In the app choose Folder to draw -> All folders, or pick one.
