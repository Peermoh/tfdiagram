# Azure web stack sample
VNet with web and data subnets, NSG, VM with public IP, storage, SQL and Key Vault.
