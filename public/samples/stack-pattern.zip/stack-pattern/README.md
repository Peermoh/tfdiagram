# stack.json sample
Capability lists per tier (no Terraform resources). Pick dev or staging under Folder to draw.
