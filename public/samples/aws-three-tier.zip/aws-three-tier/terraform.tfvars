environment          = "prod"
instance_count       = 2
create_assets_bucket = true
