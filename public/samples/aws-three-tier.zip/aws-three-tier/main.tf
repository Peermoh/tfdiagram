terraform {
  required_providers {
    aws = { source = "hashicorp/aws" }
  }
}

provider "aws" {
  region = var.region
}

module "network" {
  source   = "./modules/network"
  vpc_cidr = var.vpc_cidr
}

# --- security groups: internet -> ALB -> app -> database
resource "aws_security_group" "alb" {
  name   = "${var.environment}-alb"
  vpc_id = module.network.vpc_id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "app" {
  name   = "${var.environment}-app"
  vpc_id = module.network.vpc_id

  ingress {
    from_port       = 8080
    to_port         = 8080
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }
}

resource "aws_security_group" "db" {
  name   = "${var.environment}-db"
  vpc_id = module.network.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.app.id]
  }
}

# --- load balancer
resource "aws_lb" "app" {
  name            = "${var.environment}-alb"
  subnets         = module.network.public_subnet_ids
  security_groups = [aws_security_group.alb.id]
}

resource "aws_lb_target_group" "app" {
  name     = "${var.environment}-app"
  port     = 8080
  protocol = "HTTP"
  vpc_id   = module.network.vpc_id
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.app.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app.arn
  }
}

# --- application servers (count comes from terraform.tfvars)
resource "aws_instance" "app" {
  count                  = var.instance_count
  ami                    = "ami-0abcdef1234567890"
  instance_type          = "t3.small"
  subnet_id              = module.network.private_subnet_ids[0]
  vpc_security_group_ids = [aws_security_group.app.id]
  tags = { Name = "${var.environment}-app-${count.index}" }
}

resource "aws_lb_target_group_attachment" "app" {
  count            = var.instance_count
  target_group_arn = aws_lb_target_group.app.arn
  target_id        = aws_instance.app[count.index].id
}

# --- database
resource "aws_db_subnet_group" "db" {
  name       = "${var.environment}-db"
  subnet_ids = module.network.private_subnet_ids
}

resource "aws_db_instance" "db" {
  identifier             = "${var.environment}-db"
  engine                 = "postgres"
  instance_class         = "db.t3.medium"
  allocated_storage      = 20
  db_subnet_group_name   = aws_db_subnet_group.db.name
  vpc_security_group_ids = [aws_security_group.db.id]
  skip_final_snapshot    = true
}

# --- assets bucket, only when enabled
resource "aws_s3_bucket" "assets" {
  count  = var.create_assets_bucket ? 1 : 0
  bucket = "${var.environment}-assets-example"
}
