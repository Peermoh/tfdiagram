variable "region" { default = "us-east-1" }
variable "environment" { default = "dev" }
variable "vpc_cidr" { default = "10.0.0.0/16" }
variable "instance_count" { default = 1 }
variable "create_assets_bucket" { default = false }
