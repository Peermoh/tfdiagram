# AWS three-tier sample
Internet -> ALB -> app servers -> Postgres, with a local network module and terraform.tfvars.
